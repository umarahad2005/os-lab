package ui;

import core.ProcessManager;
import model.PCB;
import model.ProcessState;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ControlPanel extends JFrame {

    private final ProcessManager manager = new ProcessManager();
    private final ProcessTableModel tableModel = new ProcessTableModel();
    private final JTable table = new JTable(tableModel);
    private final JTextArea logArea = new JTextArea(8, 40);
    private final JLabel runningLabel = new JLabel("(none)");
    private final JLabel readyLabel = new JLabel("[]");
    private final JLabel waitingLabel = new JLabel("[]");
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");

    public ControlPanel() {
        super("Core Sim  •  OS Kernel Simulator");
        manager.setLogger(this::appendLog);
        Theme.apply();
        buildUi();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 720);
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBackground(Theme.BG_DEEP);
        root.setBorder(new EmptyBorder(14, 14, 14, 14));
        setContentPane(root);

        root.add(buildHeader(), BorderLayout.NORTH);
        root.add(buildSidebar(), BorderLayout.WEST);
        root.add(buildCenter(), BorderLayout.CENTER);

        refresh();
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.BG_PANEL);
        header.setBorder(new EmptyBorder(14, 18, 14, 18));

        JLabel title = new JLabel("◈  CORE SIM");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Theme.ACCENT);

        JLabel sub = new JLabel("Module 1  •  PCB & Process Management");
        sub.setFont(Theme.FONT_BODY);
        sub.setForeground(Theme.TEXT_DIM);
        sub.setBorder(new EmptyBorder(0, 14, 0, 0));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        left.setOpaque(false);
        left.add(title);
        left.add(sub);

        JLabel team = new JLabel("Umar Ahad Usmani (60199)  •  Noreen Tariq (61291)");
        team.setFont(Theme.FONT_BODY);
        team.setForeground(Theme.TEXT_DIM);

        header.add(left, BorderLayout.WEST);
        header.add(team, BorderLayout.EAST);
        return wrapRounded(header);
    }

    private JComponent buildSidebar() {
        JPanel buttons = new JPanel();
        buttons.setLayout(new BoxLayout(buttons, BoxLayout.Y_AXIS));
        buttons.setOpaque(false);

        buttons.add(actionButton("＋  Create Process",         Theme.SUCCESS, e -> onCreate()));
        buttons.add(actionButton("▶  Dispatch (Ready→Run)",    Theme.ACCENT,  e -> { manager.dispatch(); refresh(); }));
        buttons.add(actionButton("✕  Destroy Process",         Theme.DANGER,  e -> onPidAction("Destroy", manager::destroyProcess)));
        buttons.add(actionButton("❚❚  Suspend Process",        Theme.WARN,    e -> onPidAction("Suspend", manager::suspendProcess)));
        buttons.add(actionButton("↻  Resume Process",          Theme.SUCCESS, e -> onPidAction("Resume",  manager::resumeProcess)));
        buttons.add(actionButton("■  Block Process",           Theme.WARN,    e -> onPidAction("Block",   manager::blockProcess)));
        buttons.add(actionButton("☼  Wakeup Process",          Theme.INFO,    e -> onPidAction("Wakeup",  manager::wakeupProcess)));
        buttons.add(actionButton("⇅  Change Priority",         Theme.ACCENT_2,e -> onChangePriority()));
        buttons.add(Box.createVerticalStrut(10));
        buttons.add(actionButton("🗑  Clear Log",              Theme.TEXT_DIM,e -> logArea.setText("")));
        buttons.add(Box.createVerticalGlue());

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.setBorder(Theme.titled("Operations"));
        wrap.setBackground(Theme.BG_PANEL);
        wrap.add(buttons, BorderLayout.NORTH);

        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(Theme.BG_PANEL);
        container.add(wrap, BorderLayout.CENTER);
        container.setPreferredSize(new Dimension(260, 0));
        return wrapRounded(container);
    }

    private JComponent buildCenter() {
        JPanel center = new JPanel(new BorderLayout(12, 12));
        center.setOpaque(false);

        center.add(buildQueues(), BorderLayout.NORTH);
        center.add(buildTable(), BorderLayout.CENTER);
        center.add(buildLog(), BorderLayout.SOUTH);
        return center;
    }

    private JComponent buildQueues() {
        JPanel queues = new JPanel(new GridLayout(1, 3, 12, 0));
        queues.setOpaque(false);
        queues.add(statCard("CPU - Running", runningLabel, Theme.SUCCESS));
        queues.add(statCard("Ready Queue",   readyLabel,   Theme.ACCENT));
        queues.add(statCard("Waiting Queue", waitingLabel, Theme.WARN));
        return queues;
    }

    private JComponent statCard(String title, JLabel valueLabel, Color accent) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(Theme.BG_PANEL);
        card.setBorder(new EmptyBorder(14, 16, 14, 16));

        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.BOLD, 12));
        t.setForeground(accent);

        valueLabel.setFont(new Font(Font.MONOSPACED, Font.BOLD, 14));
        valueLabel.setForeground(Theme.TEXT);

        card.add(t, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return wrapRounded(card);
    }

    private JComponent buildTable() {
        table.setRowHeight(26);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setBackground(Theme.BG_PANEL);
        table.setForeground(Theme.TEXT);
        table.setSelectionBackground(Theme.BG_RAISED);
        table.setSelectionForeground(Theme.ACCENT);
        table.setFont(Theme.FONT_BODY);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setBackground(Theme.BG_RAISED);
        table.getTableHeader().setForeground(Theme.ACCENT);
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER));
        table.setDefaultRenderer(Object.class, new ZebraRenderer());

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(Theme.BG_PANEL);

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setBackground(Theme.BG_PANEL);
        wrap.setBorder(Theme.titled("Process Table (PCB List)"));
        wrap.add(scroll, BorderLayout.CENTER);
        return wrapRounded(wrap);
    }

    private JComponent buildLog() {
        logArea.setEditable(false);
        logArea.setFont(Theme.FONT_MONO);
        logArea.setBackground(Theme.BG_DEEP);
        logArea.setForeground(Theme.TEXT);
        logArea.setCaretColor(Theme.ACCENT);
        logArea.setBorder(new EmptyBorder(8, 10, 8, 10));

        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(BorderFactory.createEmptyBorder());
        logScroll.getViewport().setBackground(Theme.BG_DEEP);

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setBackground(Theme.BG_PANEL);
        wrap.setBorder(Theme.titled("Event Log"));
        wrap.add(logScroll, BorderLayout.CENTER);
        wrap.setPreferredSize(new Dimension(0, 200));
        return wrapRounded(wrap);
    }

    private JComponent wrapRounded(JComponent inner) {
        RoundedContainer rc = new RoundedContainer();
        rc.setLayout(new BorderLayout());
        rc.add(inner, BorderLayout.CENTER);
        return rc;
    }

    private JButton actionButton(String text, Color accent, java.awt.event.ActionListener listener) {
        AccentPillButton b = new AccentPillButton(text, accent);
        b.addActionListener(listener);
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setBorder(new EmptyBorder(3, 0, 3, 0));
        row.add(b, BorderLayout.CENTER);
        // Wrap into the layout via a returned button-like component:
        // Simpler: just return the button itself; we manage spacing via Box.createVerticalStrut.
        return b;
    }

    private void onCreate() {
        JTextField priorityField = new JTextField("1");
        JTextField memoryField = new JTextField("128");
        Object[] msg = {"Priority (1-10):", priorityField, "Memory (MB):", memoryField};
        int res = JOptionPane.showConfirmDialog(this, msg, "Create Process", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return;
        try {
            int p = Integer.parseInt(priorityField.getText().trim());
            int m = Integer.parseInt(memoryField.getText().trim());
            manager.createProcess(p, m);
            refresh();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Priority and Memory must be integers.", "Invalid input", JOptionPane.ERROR_MESSAGE);
        }
    }

    private interface PidOp { boolean apply(int pid); }

    private void onPidAction(String label, PidOp op) {
        Integer pid = pickPid(label + " - select PID");
        if (pid == null) return;
        op.apply(pid);
        refresh();
    }

    private void onChangePriority() {
        Integer pid = pickPid("Change Priority - select PID");
        if (pid == null) return;
        String input = JOptionPane.showInputDialog(this, "New priority for P" + pid + ":", "Change Priority", JOptionPane.QUESTION_MESSAGE);
        if (input == null) return;
        try {
            manager.changePriority(pid, Integer.parseInt(input.trim()));
            refresh();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Priority must be an integer.", "Invalid input", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Integer pickPid(String title) {
        if (manager.getProcesses().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No processes available.", title, JOptionPane.WARNING_MESSAGE);
            return null;
        }
        Integer[] options = manager.getProcesses().stream().map(PCB::getPid).toArray(Integer[]::new);
        int selectedRow = table.getSelectedRow();
        Integer initial = selectedRow >= 0 ? (Integer) tableModel.getValueAt(selectedRow, 0) : options[0];
        Object choice = JOptionPane.showInputDialog(this, "Select PID:", title,
                JOptionPane.QUESTION_MESSAGE, null, options, initial);
        return choice == null ? null : (Integer) choice;
    }

    private void refresh() {
        tableModel.fireTableDataChanged();
        PCB run = manager.getRunningProcess();
        runningLabel.setText(run == null ? "(none)" : "P" + run.getPid());
        readyLabel.setText(manager.getReadyQueue().toString());
        waitingLabel.setText(manager.getWaitingQueue().toString());
    }

    private void appendLog(String msg) {
        logArea.append("[" + LocalTime.now().format(TIME_FMT) + "] " + msg + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private class ProcessTableModel extends AbstractTableModel {
        private final String[] cols = {"PID", "State", "Priority", "Memory (MB)", "Parent", "Children", "I/O"};

        public int getRowCount() { return manager.getProcesses().size(); }
        public int getColumnCount() { return cols.length; }
        public String getColumnName(int c) { return cols[c]; }

        public Object getValueAt(int row, int col) {
            PCB p = manager.getProcesses().get(row);
            return switch (col) {
                case 0 -> p.getPid();
                case 1 -> p.getState();
                case 2 -> p.getPriority();
                case 3 -> p.getMemory();
                case 4 -> p.getParentId();
                case 5 -> p.getChildren().toString();
                case 6 -> p.getIoStatus();
                default -> "";
            };
        }
    }

    private static class ZebraRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean focus, int row, int col) {
            Component c = super.getTableCellRendererComponent(t, v, sel, focus, row, col);
            if (!sel) {
                c.setBackground(row % 2 == 0 ? Theme.BG_PANEL : Theme.BG_RAISED);
                c.setForeground(Theme.TEXT);
            }
            if (col == 1 && v instanceof ProcessState ps) {
                c.setForeground(stateColor(ps));
            }
            setBorder(new EmptyBorder(0, 10, 0, 10));
            return c;
        }

        private Color stateColor(ProcessState s) {
            return switch (s) {
                case RUNNING   -> Theme.SUCCESS;
                case READY     -> Theme.ACCENT;
                case WAITING   -> Theme.WARN;
                case TERMINATED-> Theme.DANGER;
                default        -> Theme.INFO;
            };
        }
    }

    private static class RoundedContainer extends JPanel {
        RoundedContainer() {
            setOpaque(false);
            setBackground(Theme.BG_PANEL);
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Theme.BG_PANEL);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
            g2.setColor(Theme.BORDER);
            g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1f, getHeight() - 1f, 16, 16));
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static class AccentPillButton extends JButton {
        private final Color accent;
        AccentPillButton(String text, Color accent) {
            super(text);
            this.accent = accent;
            setFont(new Font("Segoe UI Semibold", Font.PLAIN, 13));
            setForeground(Theme.TEXT);
            setHorizontalAlignment(SwingConstants.LEFT);
            setBorder(new EmptyBorder(8, 14, 8, 14));
            setContentAreaFilled(false);
            setFocusPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            boolean hover = getModel().isRollover();
            boolean pressed = getModel().isPressed();
            Color bg = pressed ? accent.darker() : (hover ? blend(accent, Theme.BG_RAISED, 0.55f) : Theme.BG_RAISED);
            g2.setColor(bg);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
            // accent stripe on left
            g2.setColor(accent);
            g2.fill(new RoundRectangle2D.Float(0, 0, 4, getHeight(), 12, 12));
            g2.dispose();
            super.paintComponent(g);
        }
        private static Color blend(Color a, Color b, float t) {
            int r = (int)(a.getRed()*t   + b.getRed()*(1-t));
            int g = (int)(a.getGreen()*t + b.getGreen()*(1-t));
            int bl= (int)(a.getBlue()*t  + b.getBlue()*(1-t));
            return new Color(Math.min(255,r), Math.min(255,g), Math.min(255,bl));
        }
    }
}
